<!DOCTYPE html>
<html>
<head>
    <title>Welcome To The Era </title>
</head>
<body >
    <h1>{{ $title }}</h1>
    <h5>{{$course}}</h5>
    <h5>{{$topic}}</h5>
    <p>{{ $date }}</p>
    <p>{!!$data!!}</p>
</body>
</html>
