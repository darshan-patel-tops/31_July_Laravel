<iframe width="100%" height="600px" id="iframepdf" src="/storage/pdf/{{$material}}"></iframe>
